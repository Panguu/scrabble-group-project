# Scrabble Group Project

First player places tile in center

Each player sets their username and player number.
Each turn corresponds to a player number.

Points are allocated to players that Match words on the board

This game features bonus tiles

This game has multiplayer functionality
